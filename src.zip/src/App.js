import React from 'react'
import Home from './Pages/Homepage/Home'
const App = () => {
  return (
    <div>
      {/* <Home/> */}
      <Home />
    </div>
  )
}

export default App